import React from 'react';
import AllProducts from './AllProducts';

const ProductDetails = ( props ) => {
  const {info} = props.info;
  // Fetch product details based on the productId
console.log("product",props);
  return (
    <div>
      <h2>Product Details</h2>
      <p>Product ID: </p>
      {/* Render other product details */}
    </div>
  );
};

export default ProductDetails;
